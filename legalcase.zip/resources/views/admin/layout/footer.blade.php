<footer>
    <div class="clearfix"></div>
</footer>