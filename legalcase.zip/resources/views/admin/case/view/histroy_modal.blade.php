<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="Histroymodal">
    <div class="modal-dialog modal-md">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="myModalLabel2">Remark of Business on Date : 16-06-2016</h4>
            </div>
            <div class="modal-body">
                <div class="row">


                    <h5>N/A</h5>
                </div>


            </div>
        </div>
    </div>
