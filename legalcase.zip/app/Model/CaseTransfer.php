<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CaseTransfer extends Model
{
    //
}
