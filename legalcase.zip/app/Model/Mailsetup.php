<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Mailsetup extends Model
{
    //
}
