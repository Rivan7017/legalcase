<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class sqlBackup extends Model
{

}
