<?php

namespace App\model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use Notifiable;
}
