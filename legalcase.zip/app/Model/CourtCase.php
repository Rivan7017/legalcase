<?php

namespace App\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class CourtCase extends Model
{
    use Notifiable;
}
