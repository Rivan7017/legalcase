<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CaseLog extends Model
{
    //
}
